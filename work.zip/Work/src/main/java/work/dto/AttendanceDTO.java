/**
 * 파일명 : AttendanceDTO.java
 * 작성일 : 2025. 12. 15.
 * 설명 :
 */
package work.dto;

/**
 * @author user
 *
 */
public class AttendanceDTO {

	private String attType;   
    private String attTime;  
    private String storeName;
    private int idx;
    private String memberId;
    
	public String getAttType() {
		return attType;
	}
	public void setAttType(String attType) {
		this.attType = attType;
	}
	public String getAttTime() {
		return attTime;
	}
	public void setAttTime(String attTime) {
		this.attTime = attTime;
	}
	public String getStoreName() {
		return storeName;
	}
	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}
	public int getIdx() {
		return idx;
	}
	public void setIdx(int idx) {
		this.idx = idx;
	}
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
}
