/**
 * 파일명 : MemberDAO.java
 * 작성일 : 2025. 12. 15.
 * 설명 :
 */
package work.dao;

import java.sql.*;
import java.util.ArrayList; 
import work.util.DBConn;
import work.util.SHA256;
import work.dto.MemberDTO;

/**
 * @author user
 *
 */
public class MemberDAO {

    
    public MemberDTO login(String id, String pw) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        String sql = "SELECT mem_name, mem_role FROM tb_member WHERE mem_id = ? AND mem_pw = ?";
        
        try {
            conn = DBConn.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, id);
            pstmt.setString(2, SHA256.encrypt(pw)); 
            
            rs = pstmt.executeQuery();
            
            if (rs.next()) {
                MemberDTO dto = new MemberDTO();
                dto.setId(id);
                dto.setName(rs.getString("mem_name"));
                dto.setRole(rs.getString("mem_role") != null ? rs.getString("mem_role").trim() : null);
                return dto;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            closeAll(conn, pstmt, rs);
        }
        return null;
    }

    
    public MemberDTO getMember(String id) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = "SELECT * FROM tb_member WHERE mem_id = ?";
        
        try {
            conn = DBConn.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, id);
            rs = pstmt.executeQuery();
            
            if (rs.next()) {
                MemberDTO dto = new MemberDTO();
                dto.setId(rs.getString("mem_id"));
                
                // 🚨 [필수 추가] 이 줄이 없어서 비밀번호가 null이었습니다!
                dto.setPw(rs.getString("mem_pw")); 
                
                dto.setName(rs.getString("mem_name"));
                dto.setPhone(rs.getString("mem_phone"));
                dto.setRole(rs.getString("mem_role") != null ? rs.getString("mem_role").trim() : null);
                dto.setHourlyWage(rs.getInt("hourly_wage"));
                dto.setStoreId(rs.getString("store_id")); 
                
                return dto;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            closeAll(conn, pstmt, rs);
        }
        return null;
    }

    
    public String findId(String name, String phone) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = "SELECT mem_id FROM tb_member WHERE mem_name = ? AND mem_phone = ?";
        
        try {
            conn = DBConn.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, name);
            pstmt.setString(2, phone);
            rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getString("mem_id");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            closeAll(conn, pstmt, rs);
        }
        return null;
    }

    
    public String resetPw(String id, String phone) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        String checkSql = "SELECT mem_id FROM tb_member WHERE mem_id = ? AND mem_phone = ?";
        String updateSql = "UPDATE tb_member SET mem_pw = ? WHERE mem_id = ?";
        
        try {
            conn = DBConn.getConnection();
            pstmt = conn.prepareStatement(checkSql);
            pstmt.setString(1, id);
            pstmt.setString(2, phone);
            rs = pstmt.executeQuery();
            
            if (rs.next()) {
                
                int randomNum = (int)(Math.random() * 9000) + 1000;
                String tempPw = String.valueOf(randomNum); 
                
                pstmt.close(); 
                pstmt = conn.prepareStatement(updateSql);
                pstmt.setString(1, SHA256.encrypt(tempPw)); 
                pstmt.setString(2, id);
                pstmt.executeUpdate();
                
                return tempPw; 
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            closeAll(conn, pstmt, rs);
        }
        return null;
    }

    
    public boolean updateMember(String id, String newPw, String newPhone) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        String sql = "";
        
        try {
            conn = DBConn.getConnection();
            
            if (newPw != null && !newPw.isEmpty()) {
                sql = "UPDATE tb_member SET mem_phone = ?, mem_pw = ? WHERE mem_id = ?";
                pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, newPhone);
                pstmt.setString(2, SHA256.encrypt(newPw));
                pstmt.setString(3, id);
            } else {
                sql = "UPDATE tb_member SET mem_phone = ? WHERE mem_id = ?";
                pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, newPhone);
                pstmt.setString(2, id);
            }
            return pstmt.executeUpdate() > 0;
            
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            closeAll(conn, pstmt, null);
        }
    }

    
    public String getStoreName(String storeId) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = "SELECT store_name FROM tb_store WHERE store_id = ?";
        
        try {
            conn = DBConn.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, storeId);
            rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getString("store_name");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            closeAll(conn, pstmt, rs);
        }
        return "등록된 매장 없음";
    }

    
    public boolean isStoreExists(String storeId) {
        if (storeId == null || storeId.trim().isEmpty()) return false;

        // 입력값의 앞뒤 공백을 제거하여 정확하게 비교한다.
        String cleanId = storeId.trim();
        String sql = "SELECT COUNT(*) FROM tb_store WHERE store_id = ?";
        
        try (Connection conn = DBConn.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, cleanId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0; 
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    
    public boolean addMyStore(String userId, String storeId) {
        // 직원이 매장 소속 신청 시 PENDING으로 저장, 점장이 매장 생성 시 ACTIVE로 저장
        String sql = "INSERT INTO tb_my_stores (mem_id, store_id, join_status) VALUES (?, ?, 'PENDING')";
        try (Connection conn = DBConn.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, userId);
            pstmt.setString(2, storeId);
            return pstmt.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // 점장용: 매장 생성 시 ACTIVE로 바로 저장
    public boolean addMyStoreActive(String userId, String storeId) {
        String sql = "INSERT INTO tb_my_stores (mem_id, store_id, join_status) VALUES (?, ?, 'ACTIVE')";
        try (Connection conn = DBConn.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, userId);
            pstmt.setString(2, storeId);
            return pstmt.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    
    // 내 매장 목록 (ACTIVE만 - navbar 매장변경 모달용)
    public ArrayList<String[]> getMyStoreList(String userId) {
        ArrayList<String[]> list = new ArrayList<>();
        String sql = "SELECT ms.store_id, s.store_name FROM tb_my_stores ms " +
                     "JOIN tb_store s ON ms.store_id = s.store_id " +
                     "WHERE ms.mem_id = ? AND ms.join_status = 'ACTIVE' AND s.store_status = 'ACTIVE'";
        try (Connection conn = DBConn.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, userId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    list.add(new String[]{rs.getString("store_id"), rs.getString("store_name")});
                }
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    // 내 매장 목록 전체 (PENDING 포함 - store_manage.jsp용)
    public ArrayList<String[]> getMyStoreListAll(String userId) {
        ArrayList<String[]> list = new ArrayList<>();
        String sql = "SELECT ms.store_id, s.store_name, ms.join_status, s.store_status " +
                     "FROM tb_my_stores ms " +
                     "JOIN tb_store s ON ms.store_id = s.store_id " +
                     "WHERE ms.mem_id = ?";
        try (Connection conn = DBConn.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, userId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    list.add(new String[]{
                        rs.getString("store_id"),
                        rs.getString("store_name"),
                        rs.getString("join_status"),   // [2]: PENDING/ACTIVE
                        rs.getString("store_status")   // [3]: 매장 승인 상태
                    });
                }
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    // 점장용: 내 매장에 소속 신청한 직원 목록 조회
    public ArrayList<String[]> getPendingJoins(String storeId) {
        ArrayList<String[]> list = new ArrayList<>();
        String sql = "SELECT ms.mem_id, m.mem_name, m.mem_phone " +
                     "FROM tb_my_stores ms " +
                     "JOIN tb_member m ON ms.mem_id = m.mem_id " +
                     "WHERE ms.store_id = ? AND ms.join_status = 'PENDING'";
        try (Connection conn = DBConn.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, storeId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    list.add(new String[]{
                        rs.getString("mem_id"),
                        rs.getString("mem_name"),
                        rs.getString("mem_phone")
                    });
                }
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    // 점장: 직원 소속 신청 승인
    public boolean approveJoin(String memId, String storeId) {
        String sql = "UPDATE tb_my_stores SET join_status = 'ACTIVE' " +
                     "WHERE mem_id = ? AND store_id = ? AND join_status = 'PENDING'";
        try (Connection conn = DBConn.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, memId);
            pstmt.setString(2, storeId);
            return pstmt.executeUpdate() > 0;
        } catch (Exception e) { e.printStackTrace(); return false; }
    }

    // 점장: 직원 소속 신청 거절 (tb_my_stores에서 삭제)
    public boolean rejectJoin(String memId, String storeId) {
        String sql = "DELETE FROM tb_my_stores WHERE mem_id = ? AND store_id = ? AND join_status = 'PENDING'";
        try (Connection conn = DBConn.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, memId);
            pstmt.setString(2, storeId);
            return pstmt.executeUpdate() > 0;
        } catch (Exception e) { e.printStackTrace(); return false; }
    }

    
    private void closeAll(Connection conn, PreparedStatement pstmt, ResultSet rs) {
        if(rs != null) try{ rs.close(); } catch(Exception e){}
        if(pstmt != null) try{ pstmt.close(); } catch(Exception e){}
        DBConn.close(conn);
    }
    
 // MemberDAO.java - 이 이름 하나로 통일해서 쓰세요!
    public ArrayList<MemberDTO> getStoreMembers(String storeId) {
        ArrayList<MemberDTO> list = new ArrayList<>();
        
        // 1. tb_my_stores를 사용하고 모든 컬럼을 가져옵니다.
        String sql = "SELECT m.mem_id, m.mem_name, m.mem_phone, m.hourly_wage, m.mem_role " +
                     "FROM tb_member m " +
                     "JOIN tb_my_stores ms ON m.mem_id = ms.mem_id " +
                     "WHERE ms.store_id = ? " +
                     "ORDER BY m.mem_name";

        try (Connection conn = DBConn.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, storeId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    MemberDTO dto = new MemberDTO();
                    dto.setId(rs.getString("mem_id"));
                    dto.setName(rs.getString("mem_name"));
                    dto.setPhone(rs.getString("mem_phone")); // 연락처 매핑
                    dto.setHourlyWage(rs.getInt("hourly_wage")); // 시급 매핑
                    dto.setRole(rs.getString("mem_role") != null ? rs.getString("mem_role").trim() : null); // 권한 매핑
                    list.add(dto);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }    public boolean updateMemberWage(String id, int wage) {
        String sql = "UPDATE tb_member SET hourly_wage = ? WHERE mem_id = ?";
        
        // DB 연결 정보 (기존 DAO에 정의된 변수가 있다면 그걸 사용하세요)
        String dbUrl = "jdbc:sqlserver://localhost:1433;databaseName=Work;encrypt=false";
        String dbId = "WorkUser";
        String dbPw = "pass";

        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            try (Connection conn = DriverManager.getConnection(dbUrl, dbId, dbPw);
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {
                
                pstmt.setInt(1, wage);
                pstmt.setString(2, id);
                
                int result = pstmt.executeUpdate();
                return result > 0; // 1행 이상 수정되었다면 성공(true) 반환
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public boolean deleteMember(String memId) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DBConn.getConnection();
            conn.setAutoCommit(false); // 🚨 여러 삭제 작업을 하나로 묶기 위해 트랜잭션 시작

            // 1. 연결 장부(tb_my_stores)에서 해당 사용자의 기록을 먼저 삭제
            String sql1 = "DELETE FROM tb_my_stores WHERE mem_id = ?";
            pstmt = conn.prepareStatement(sql1);
            pstmt.setString(1, memId);
            pstmt.executeUpdate();
            pstmt.close();

            // 2. 실제 회원 테이블(tb_member)에서 사용자 삭제
            String sql2 = "DELETE FROM tb_member WHERE mem_id = ?";
            pstmt = conn.prepareStatement(sql2);
            pstmt.setString(1, memId);
            int result = pstmt.executeUpdate();

            conn.commit(); // 모든 삭제 성공 시 확정
            return result > 0;

        } catch (Exception e) {
            try { if(conn != null) conn.rollback(); } catch(Exception ex) {} // 실패 시 롤백
            e.printStackTrace();
            return false;
        } finally {
            DBConn.closeAll(conn, pstmt, null);
        }
    }
    
    public ArrayList<MemberDTO> getAllMembers() {
        ArrayList<MemberDTO> list = new ArrayList<>();
        String sql = "SELECT mem_name, mem_id, store_id, hourly_wage FROM tb_member";
        
        // DB 정보 (기존 DAO 설정과 동일하게)
        String dbUrl = "jdbc:sqlserver://localhost:1433;databaseName=Work;encrypt=false";
        
        try (Connection conn = DriverManager.getConnection(dbUrl, "WorkUser", "pass");
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            
            while(rs.next()) {
                MemberDTO m = new MemberDTO();
                m.setName(rs.getString("mem_name"));
                m.setId(rs.getString("mem_id"));
                m.setStoreId(rs.getString("store_id"));
                m.setHourlyWage(rs.getInt("hourly_wage"));
                list.add(m);
            }
        } catch(Exception e) { e.printStackTrace(); }
        return list;
    }
            
    public boolean registerMember(MemberDTO dto, String storeId) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DBConn.getConnection();
            conn.setAutoCommit(false);

            // 1. 회원 정보 저장 (tb_member) - 점장은 PENDING, 직원은 ACTIVE
            String memStatus = "A".equals(dto.getRole()) ? "PENDING" : "ACTIVE";
            String sql1 = "INSERT INTO tb_member (mem_id, mem_pw, mem_name, mem_phone, mem_role, hourly_wage, store_id, mem_status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            pstmt = conn.prepareStatement(sql1);
            pstmt.setString(1, dto.getId());
            pstmt.setString(2, dto.getPw());
            pstmt.setString(3, dto.getName());
            pstmt.setString(4, dto.getPhone());
            pstmt.setString(5, dto.getRole());
            pstmt.setInt(6, dto.getHourlyWage());
            pstmt.setString(7, storeId);
            pstmt.setString(8, memStatus);
            pstmt.executeUpdate();
            pstmt.close();

            // 2. 직원인 경우 매장 연결 장부 저장 (tb_my_stores)
            if (storeId != null && !storeId.trim().isEmpty()) {
                String sql2 = "INSERT INTO tb_my_stores (mem_id, store_id) VALUES (?, ?)";
                pstmt = conn.prepareStatement(sql2);
                pstmt.setString(1, dto.getId());
                pstmt.setString(2, storeId);
                pstmt.executeUpdate();
                pstmt.close();
            }

            conn.commit();
            return true;
        } catch (Exception e) {
            try { if(conn != null) conn.rollback(); } catch(Exception ex) {}
            e.printStackTrace();
            return false;
        } finally {
            DBConn.closeAll(conn, pstmt, null);
        }
    }
    
    public boolean insertAttendance(String memId, String storeId, String type) {
        // 🚨 이미지 확인 결과: 컬럼명이 att_type(상태), att_time(시간)입니다.
        String sql = "INSERT INTO tb_attendance (mem_id, store_id, att_type, att_time) " +
                     "VALUES (?, ?, ?, GETDATE())";
        
        // type('IN'/'OUT')에 따라 DB에 저장할 한글 상태값 결정
        String statusStr = "IN".equals(type) ? "출근" : "퇴근";

        try (Connection conn = DBConn.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, memId);
            pstmt.setString(2, storeId);
            pstmt.setString(3, statusStr); // att_type 컬럼에 '출근' 또는 '퇴근' 저장
            
            // 실행 결과가 1행 이상이면 성공(true) 반환
            return pstmt.executeUpdate() > 0;
        } catch (Exception e) {
            System.err.println("❌ 출퇴근 기록 중 SQL 오류 발생!");
            e.printStackTrace();
            return false;
        }
    }
    
 // MemberDAO.java에 추가
    public boolean updateStore(String userId, String storeId) {
        // 1. 먼저 해당 매장이 존재하는지 체크 (기존 메서드 활용)
        if (!isStoreExists(storeId)) return false;

        // 2. 존재한다면 사용자의 소속 매장 업데이트
        String sql = "UPDATE tb_member SET store_id = ? WHERE mem_id = ?";
        try (Connection conn = DBConn.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, storeId);
            pstmt.setString(2, userId);
            
            return pstmt.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public boolean removeStaffFromStore(String memId, String storeId) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DBConn.getConnection();
            conn.setAutoCommit(false); // 🚨 트랜잭션 시작 (두 작업을 하나로 묶음)

            // 1. 연결 장부(tb_my_stores)에서 해당 매장 소속 정보 삭제
            String sql1 = "DELETE FROM tb_my_stores WHERE mem_id = ? AND store_id = ?";
            pstmt = conn.prepareStatement(sql1);
            pstmt.setString(1, memId);
            pstmt.setString(2, storeId);
            pstmt.executeUpdate();
            pstmt.close();

            // 2. 회원 테이블(tb_member)의 현재 매장 정보가 삭제한 매장과 같다면 NULL로 초기화
            // 🚨 이 부분이 빠지면 default.jsp에서 계속 이전 매장이 보입니다.
            String sql2 = "UPDATE tb_member SET store_id = NULL WHERE mem_id = ? AND store_id = ?";
            pstmt = conn.prepareStatement(sql2);
            pstmt.setString(1, memId);
            pstmt.setString(2, storeId);
            pstmt.executeUpdate();

            conn.commit(); // 모든 작업 성공 시 확정
            return true;
        } catch (Exception e) {
            try { if(conn != null) conn.rollback(); } catch(Exception ex) {} // 실패 시 롤백
            e.printStackTrace();
            return false;
        } finally {
            DBConn.closeAll(conn, pstmt, null);
        }
    }
    public boolean isAlreadyJoined(String memId, String storeId) {
        String sql = "SELECT COUNT(*) FROM tb_my_stores WHERE mem_id = ? AND store_id = ?";
        try (Connection conn = DBConn.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, memId);
            pstmt.setString(2, storeId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) return rs.getInt(1) > 0;
            }
        } catch (Exception e) { e.printStackTrace(); }
        return false;
    }
    // 점장용: 본인 소유 전체 매장의 소속 신청 대기 목록 (매장 선택 무관)
    public ArrayList<String[]> getPendingJoinsByOwner(String ownerId) {
        ArrayList<String[]> list = new ArrayList<>();
        String sql = "SELECT ms.mem_id, m.mem_name, m.mem_phone, ms.store_id, s.store_name " +
                     "FROM tb_my_stores ms " +
                     "JOIN tb_member m ON ms.mem_id = m.mem_id " +
                     "JOIN tb_store s ON ms.store_id = s.store_id " +
                     "WHERE ms.join_status = 'PENDING' " +
                     "AND ms.store_id IN (" +
                     "  SELECT store_id FROM tb_my_stores WHERE mem_id = ? AND join_status = 'ACTIVE'" +
                     ")";
        try (Connection conn = DBConn.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, ownerId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    list.add(new String[]{
                        rs.getString("mem_id"),    // [0] 직원 아이디
                        rs.getString("mem_name"),  // [1] 직원 이름
                        rs.getString("mem_phone"), // [2] 전화번호
                        rs.getString("store_id"),  // [3] 매장 코드
                        rs.getString("store_name") // [4] 매장 이름
                    });
                }
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    // 매장 생성 신청 (PENDING 상태로 저장)
    public boolean requestCreateStore(String memId, String storeId, String storeName) {
        // 중복 체크
        if (isStoreExists(storeId)) return false;

        String sql = "INSERT INTO tb_store (store_id, store_name, qr_key, store_status) VALUES (?, ?, ?, 'PENDING')";
        try (Connection conn = DBConn.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, storeId.trim());
            pstmt.setString(2, storeName.trim());
            pstmt.setString(3, "QR_" + storeId.trim() + "_" + System.currentTimeMillis());
            return pstmt.executeUpdate() > 0;
        } catch (Exception e) { e.printStackTrace(); return false; }
    }

    // 승인 대기 중인 매장 목록 조회 (전체관리자용)
    public ArrayList<String[]> getPendingStores() {
        ArrayList<String[]> list = new ArrayList<>();
        // tb_member와 join해서 신청한 점장 이름도 같이 가져옴
        String sql = "SELECT s.store_id, s.store_name, m.mem_name, m.mem_id " +
                     "FROM tb_store s " +
                     "JOIN tb_my_stores ms ON s.store_id = ms.store_id " +
                     "JOIN tb_member m ON ms.mem_id = m.mem_id " +
                     "WHERE s.store_status = 'PENDING'";
        try (Connection conn = DBConn.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                list.add(new String[]{
                    rs.getString("store_id"),
                    rs.getString("store_name"),
                    rs.getString("mem_name"),
                    rs.getString("mem_id")
                });
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    // 매장 승인
    public boolean approveStore(String storeId) {
        String sql = "UPDATE tb_store SET store_status = 'ACTIVE' WHERE store_id = ? AND store_status = 'PENDING'";
        try (Connection conn = DBConn.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, storeId);
            return pstmt.executeUpdate() > 0;
        } catch (Exception e) { e.printStackTrace(); return false; }
    }

    // 매장 거절 (tb_store, tb_my_stores 모두 삭제)
    public boolean rejectStore(String storeId) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = DBConn.getConnection();
            conn.setAutoCommit(false);
            // 1. tb_my_stores에서 삭제
            pstmt = conn.prepareStatement("DELETE FROM tb_my_stores WHERE store_id = ?");
            pstmt.setString(1, storeId);
            pstmt.executeUpdate();
            pstmt.close();
            // 2. tb_store에서 삭제
            pstmt = conn.prepareStatement("DELETE FROM tb_store WHERE store_id = ? AND store_status = 'PENDING'");
            pstmt.setString(1, storeId);
            pstmt.executeUpdate();
            conn.commit();
            return true;
        } catch (Exception e) {
            try { if (conn != null) conn.rollback(); } catch (Exception ex) {}
            e.printStackTrace(); return false;
        } finally { DBConn.closeAll(conn, pstmt, null); }
    }
    public ArrayList<MemberDTO> getPendingMembers() {
        ArrayList<MemberDTO> list = new ArrayList<>();
        String sql = "SELECT mem_id, mem_name, mem_phone, mem_role " +
                     "FROM tb_member WHERE mem_status = 'PENDING' ORDER BY reg_date ASC";
        try (Connection conn = DBConn.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                MemberDTO dto = new MemberDTO();
                dto.setId(rs.getString("mem_id"));
                dto.setName(rs.getString("mem_name"));
                dto.setPhone(rs.getString("mem_phone"));
                dto.setRole(rs.getString("mem_role") != null ? rs.getString("mem_role").trim() : null);
                list.add(dto);
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    // 점장 가입 승인 처리
    public boolean approveMember(String memId) {
        String sql = "UPDATE tb_member SET mem_status = 'ACTIVE' WHERE mem_id = ? AND mem_status = 'PENDING'";
        try (Connection conn = DBConn.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, memId);
            return pstmt.executeUpdate() > 0;
        } catch (Exception e) { e.printStackTrace(); return false; }
    }

    // 점장 가입 거절 처리
    public boolean rejectMember(String memId) {
        String sql = "UPDATE tb_member SET mem_status = 'REJECTED' WHERE mem_id = ? AND mem_status = 'PENDING'";
        try (Connection conn = DBConn.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, memId);
            return pstmt.executeUpdate() > 0;
        } catch (Exception e) { e.printStackTrace(); return false; }
    }

    // 회원 status 조회 (로그인 시 체크용)
    public String getMemberStatus(String memId) {
        String sql = "SELECT mem_status FROM tb_member WHERE mem_id = ?";
        try (Connection conn = DBConn.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, memId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) return rs.getString("mem_status");
            }
        } catch (Exception e) { e.printStackTrace(); }
        return null;
    }
}