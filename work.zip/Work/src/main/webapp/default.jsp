<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.Date" %>
<%@ page import="java.text.SimpleDateFormat" %>
<%@ page import="java.util.ArrayList" %>
<%@ page import="work.dao.MemberDAO" %>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title>AlbaPass - 통합 대시보드</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="<%=request.getContextPath()%>/jlogo.png">	
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Pretendard:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<%=request.getContextPath()%>/css/style.css">
    
    <style>
        body { background-color: #f8f9fc; font-family: 'Pretendard', sans-serif; }
        .board-table th { background-color: #f8f9fc; font-size: 0.85rem; color: #4e73df; }
        .board-table td { font-size: 0.9rem; vertical-align: middle; }
        .custom-card { border-radius: 12px; transition: all 0.2s ease; border: none; }
        .custom-card:hover { transform: translateY(-3px); box-shadow: 0 10px 20px rgba(0,0,0,0.08) !important; }
        .action-card { cursor: pointer; }
        .icon-box { width: 50px; height: 50px; border-radius: 12px; display: flex; align-items: center; justify-content: center; }
    </style>
</head>
<body>

<%
    String userId = (String)session.getAttribute("userId");
    String userName = (String)session.getAttribute("userName");
    String userRole = (String)session.getAttribute("userRole"); 
    String userStoreId = (String)session.getAttribute("userStoreId"); 

    // SA(전체관리자)는 전용 페이지로 리다이렉트
    if ("SA".equals(userRole)) {
        response.sendRedirect("SuperAdminMain");
        return;
    }

    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    String today = sdf.format(new Date());

    // 점장인 경우 소속 신청 대기 건수 조회
    int pendingJoinCount = 0;
    if ("A".equals(userRole) && userId != null) {
        MemberDAO dao = new MemberDAO();
        pendingJoinCount = dao.getPendingJoinsByOwner(userId).size();
    }
%>

<%@ include file="navbar.jsp" %>

<div class="container my-5" style="padding-top: 20px;">
    <% if (userId == null) { %>
	    <div class="promo-banner p-5 mb-5 shadow-lg position-relative text-center">
	        <i class="fa-solid fa-mobile-screen promo-bg-icon" style="right: 5%; bottom: -20px; opacity: 0.07;"></i>
	        
	        <div class="row justify-content-center position-relative" style="z-index: 2;">
	            <div class="col-lg-10">
	                <span class="badge bg-white text-primary fw-bold mb-3 px-3 py-2 animate__animated animate__fadeInDown">NEW AlbaPass 2.0</span>
	                <h1 class="display-4 fw-bold mb-3">출퇴근 기록부터<br>자동 급여 정산까지 한 번에</h1>
	                <p class="lead mb-5 opacity-90">
	                    복잡한 알바 관리, 이제 QR 스캔 한 번으로 해결하세요.<br>
	                    가장 스마트한 근태관리 파트너 <strong>AlbaPass</strong>입니다.
	                </p>
	                <div class="d-flex justify-content-center gap-3">
	                    <a href="login.jsp" class="btn btn-light btn-lg px-5 fw-bold text-primary shadow-sm">시작하기</a>
	                    <a href="register.jsp" class="btn btn-outline-light btn-lg px-5 fw-bold">회원가입</a>
	                </div>
	            </div>
	        </div>
	    </div>
	
	    <div class="row g-4 mb-5 text-center">
	        <div class="col-md-4">
	            <div class="p-3">
	                <div class="feature-icon"><i class="fa-solid fa-bolt-lightning text-warning fa-xl"></i></div>
	                <h5 class="fw-bold text-dark">스마트한 QR 인증</h5>
	                <p class="text-muted small">수동 장부 대신 QR 스캔으로<br>1초 만에 출퇴근을 기록한다.</p>
	            </div>
	        </div>
	        <div class="col-md-4 border-start border-end d-none d-md-block">
	            <div class="p-3">
	                <div class="feature-icon"><i class="fa-solid fa-calculator text-success fa-xl"></i></div>
	                <h5 class="fw-bold text-dark">자동 급여 정산</h5>
	                <p class="text-muted small">근무 기록을 바탕으로 이번 달<br>예상 월급을 실시간 확인한다.</p>
	            </div>
	        </div>
	        <div class="col-md-4 d-md-none">
	            <div class="p-3">
	                <div class="feature-icon"><i class="fa-solid fa-calculator text-success fa-xl"></i></div>
	                <h5 class="fw-bold text-dark">자동 급여 정산</h5>
	                <p class="text-muted small">근무 기록을 바탕으로 이번 달<br>예상 월급을 실시간 확인한다.</p>
	            </div>
	        </div>
	        <div class="col-md-4">
	            <div class="p-3">
	                <div class="feature-icon"><i class="fa-solid fa-layer-group text-info fa-xl"></i></div>
	                <h5 class="fw-bold text-dark">멀티 매장 지원</h5>
	                <p class="text-muted small">계정 하나로 모든 근무지를<br>간편하게 스위칭하며 관리한다.</p>
	            </div>
	        </div>
	    </div>
	<% } else { %>
        <div class="alert bg-white shadow-sm d-flex justify-content-between align-items-center mb-4 border-start border-primary border-5 rounded-3 py-3">
            <div>
                <h6 class="text-muted mb-1 small text-uppercase fw-bold">현재 접속 매장</h6>
                <h5 class="fw-bold mb-0 text-dark">
                    <i class="fa-solid fa-store me-2 text-primary"></i>
                    <%= (userStoreId != null && !userStoreId.isEmpty()) ? userStoreId : "매장을 선택해주세요" %>
                </h5>
            </div>
            <div class="text-end d-none d-sm-block">
                <small class="text-muted">오늘 날짜</small>
                <div class="fw-bold text-dark"><%= today %></div>
            </div>
        </div>

        <div class="row g-4 mb-5">
            <% if ("A".equals(userRole)) { %>
                <div class="col-12 col-lg-8">
                    <h5 class="fw-bold text-dark mb-4"><i class="fa-solid fa-toolbox me-2 text-primary"></i>매장 관리 도구</h5>
                    <div class="row g-3 mb-4">
                        <div class="col-6 col-md-3">
                            <a href="admin_attendance.jsp" class="card custom-card action-card p-3 h-100 text-center shadow-sm text-decoration-none">
                                <div class="icon-box bg-primary-subtle text-primary mx-auto mb-2"><i class="fa-solid fa-users-viewfinder fa-lg"></i></div>
                                <span class="fw-bold text-dark small">근태 현황</span>
                            </a>
                        </div>
                        <div class="col-6 col-md-3">
                            <a href="AdminMemberList" class="card custom-card action-card p-3 h-100 text-center shadow-sm text-decoration-none">
                                <div class="icon-box bg-info-subtle text-info mx-auto mb-2"><i class="fa-solid fa-user-gear fa-lg"></i></div>
                                <span class="fw-bold text-dark small">직원 관리</span>
                            </a>
                        </div>
                        <div class="col-6 col-md-3">
                            <a href="qr_view.jsp" class="card custom-card action-card p-3 h-100 text-center shadow-sm text-decoration-none">
                                <div class="icon-box bg-success-subtle text-success mx-auto mb-2"><i class="fa-solid fa-qrcode fa-lg"></i></div>
                                <span class="fw-bold text-dark small">QR 관리</span>
                            </a>
                        </div>
                        <div class="col-6 col-md-3">
                            <a href="AdminStats" class="card custom-card action-card p-3 h-100 text-center shadow-sm text-decoration-none">
                                <div class="icon-box bg-warning-subtle text-warning mx-auto mb-2"><i class="fa-solid fa-chart-column fa-lg"></i></div>
                                <span class="fw-bold text-dark small">매장 통계</span>
                            </a>
                        </div>
                        <div class="col-6 col-md-3">
                            <a href="StoreManage" class="card custom-card action-card p-3 h-100 text-center shadow-sm text-decoration-none position-relative">
                                <div class="icon-box bg-danger-subtle text-danger mx-auto mb-2"><i class="fa-solid fa-store fa-lg"></i></div>
                                <span class="fw-bold text-dark small">매장 관리</span>
                                <% if (pendingJoinCount > 0) { %>
                                <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" style="font-size:0.65rem;">
                                    <%=pendingJoinCount%>
                                </span>
                                <% } %>
                            </a>
                        </div>
                    </div>

                    <div class="card custom-card shadow-sm p-4">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h5 class="fw-bold mb-0"><i class="fa-solid fa-clipboard-list me-2 text-primary"></i>매장 게시판</h5>
                            <a href="board_list.jsp" class="btn btn-link btn-sm text-decoration-none">전체보기</a>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-hover board-table mb-0">
                                <thead>
                                    <tr><th>제목</th><th class="text-end">작성일</th></tr>
                                </thead>
                                <tbody>
                                    <jsp:include page="board_list_mini.jsp" />
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-lg-4">
                    <h5 class="fw-bold text-dark mb-4"><i class="fa-solid fa-bolt text-warning me-2"></i>빠른 실행</h5>
                    
                    <div class="card custom-card p-4 mb-3 border-top border-4 border-success shadow-sm">
                        <form action="ExcelDownload" method="get" class="row g-2 text-center">
                            <div class="col-12 fw-bold text-success mb-2 small"><i class="fa-solid fa-file-excel me-1"></i> 급여 정산서(Excel)</div>
                            <input type="hidden" name="storeId" value="<%=userStoreId%>">
                            <div class="col-6"><input type="number" name="year" value="2026" class="form-control form-control-sm text-center"></div>
                            <div class="col-6">
                                <select name="month" class="form-select form-select-sm">
                                    <% for(int i=1; i<=12; i++) { %>
                                        <option value="<%=i%>" <%= today.contains("-03-") && i==3 ? "selected" : "" %>><%=i%>월</option>
                                    <% } %>
                                </select>
                            </div>
                            <div class="col-12 mt-3"><button type="submit" class="btn btn-success btn-sm w-100 fw-bold">보고서 다운로드</button></div>
                        </form>
                    </div>

                    <div class="card custom-card p-0 overflow-hidden shadow-sm">
                        <div class="list-group list-group-flush">
                            <a href="MyPage" class="list-group-item list-group-item-action p-4 d-flex align-items-center border-0">
                                <div class="icon-box bg-info-subtle text-info me-3"><i class="fa-solid fa-user-gear fa-lg"></i></div>
                                <div>
                                    <h6 class="mb-1 fw-bold text-dark">내 정보 관리</h6>
                                    <small class="text-muted">비밀번호 변경 및 새 매장 등록</small>
                                </div>
                                <i class="fa-solid fa-chevron-right ms-auto text-light"></i>
                            </a>
                        </div>
                    </div>
                </div>

            <% } else { %>
                <div class="col-12 col-lg-8">
                    <h5 class="fw-bold text-dark mb-4"><i class="fa-solid fa-person-walking text-primary me-2"></i>나의 근무</h5>
                    <div class="row g-3 mb-4">
                        <div class="col-md-6">
                            <a href="qr_check.jsp" class="card custom-card p-4 d-flex flex-row align-items-center h-100 shadow-sm text-decoration-none">
                                <div class="icon-box bg-primary text-white shadow me-3"><i class="fa-solid fa-camera fa-lg"></i></div>
                                <div><h6 class="mb-1 fw-bold text-dark">출퇴근 찍기</h6><small class="text-muted">QR 스캔으로 기록합니다.</small></div>
                            </a>
                        </div>
                        <div class="col-md-6">
                            <a href="MyAttendance" class="card custom-card p-4 d-flex flex-row align-items-center h-100 shadow-sm text-decoration-none">
                                <div class="icon-box text-white shadow me-3" style="background:#00b894;"><i class="fa-solid fa-list-check fa-lg"></i></div>
                                <div><h6 class="mb-1 fw-bold text-dark">내 근무 기록</h6><small class="text-muted">내 출퇴근 이력을 확인합니다.</small></div>
                            </a>
                        </div>
                    </div>

                    <div class="card custom-card shadow-sm p-4">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h5 class="fw-bold mb-0"><i class="fa-solid fa-bullhorn me-2 text-success"></i>매장 게시판</h5>
                            <a href="board_list.jsp" class="btn btn-link btn-sm text-decoration-none">더보기</a>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-hover board-table mb-0">
                                <thead>
                                    <tr><th>제목</th><th class="text-end">작성일</th></tr>
                                </thead>
                                <tbody>
                                    <jsp:include page="board_list_mini.jsp" />
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-lg-4">
                    <h5 class="fw-bold text-dark mb-4"><i class="fa-solid fa-link text-secondary me-2"></i>바로가기</h5>
                    <div class="card custom-card p-0 overflow-hidden shadow-sm">
                        <div class="list-group list-group-flush">
                            <a href="MyPage" class="list-group-item list-group-item-action p-4 d-flex align-items-center border-0">
                                <div class="icon-box bg-secondary-subtle text-secondary me-3"><i class="fa-solid fa-user-gear fa-lg"></i></div>
                                <div><h6 class="mb-1 fw-bold text-dark">내 정보 관리</h6><small class="text-muted">시급 및 매장 정보 확인</small></div>
                                <i class="fa-solid fa-chevron-right ms-auto text-light"></i>
                            </a>
                            <a href="StoreManage" class="list-group-item list-group-item-action p-4 d-flex align-items-center border-0">
                                <div class="icon-box bg-warning-subtle text-warning me-3"><i class="fa-solid fa-store fa-lg"></i></div>
                                <div><h6 class="mb-1 fw-bold text-dark">매장 관리</h6><small class="text-muted">소속 매장 신청 및 관리</small></div>
                                <i class="fa-solid fa-chevron-right ms-auto text-light"></i>
                            </a>
                        </div>
                    </div>
                </div>
            <% } %>
        </div>
    <% } %>
</div>

<%@ include file="footer.jsp" %>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>