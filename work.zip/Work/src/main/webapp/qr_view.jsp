<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
    // 서블릿에서 보낸 에러 메시지 확인
    String errorMsg = (String)request.getAttribute("errorMsg");
    String userStoreId = (String)session.getAttribute("userStoreId");
%>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title>매장 QR 관리 - AlbaPass</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Pretendard:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
    <link rel="icon" type="image/png" href="<%=request.getContextPath()%>/jlogo.png">
    <link rel="stylesheet" href="<%=request.getContextPath()%>/css/style.css">

    <style>
        body { background-color: #f8f9fc; font-family: 'Pretendard', sans-serif; }
        .qr-card { max-width: 500px; margin: 60px auto; border-radius: 20px; border: none; }
        #qrcode img { margin: 0 auto; border: 12px solid #fff; border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
        
        /* 인쇄 최적화 설정 */
        @media print {
            .no-print, navbar, footer { display: none !important; }
            body { background: #fff; margin: 0; padding: 0; }
            .qr-card { box-shadow: none !important; margin: 0 auto; width: 100%; }
            .container { width: 100% !important; max-width: none !important; }
        }
    </style>
</head>
<body>

<%@ include file="navbar.jsp" %>

<div class="container">
    <div class="qr-card card p-5 shadow-sm text-center">
        <div class="d-flex justify-content-between align-items-center mb-4 no-print">
            <h5 class="fw-bold text-dark mb-0"><i class="fa-solid fa-qrcode text-success me-2"></i>매장 QR 코드</h5>
            <a href="default.jsp" class="btn btn-outline-secondary btn-sm border-0"><i class="fa-solid fa-xmark"></i></a>
        </div>

        <% if (errorMsg != null) { %>
            <div class="py-5 text-danger fw-bold">
                <i class="fa-solid fa-triangle-exclamation fa-3x mb-3"></i><br>
                <%=errorMsg%>
            </div>
        <% } else { %>
            <div class="mb-4">
                <h4 class="fw-bold text-dark mb-1">출근 체크 전용 QR</h4>
                <p class="text-muted small">직원들이 매장에서 스캔할 수 있도록 인쇄하여 비치해 주세요.</p>
            </div>

            <div id="qrcode" class="d-inline-block p-2 mb-4"></div>
            
            <div class="p-3 bg-light rounded-3 mb-4">
                <span class="text-muted small d-block mb-1 text-uppercase fw-bold">활성화된 매장 ID</span>
                <h3 class="fw-bold text-primary mb-0"><%=userStoreId%></h3>
            </div>

            <div class="no-print">
                <button onclick="window.print()" class="btn btn-dark w-100 py-3 fw-bold rounded-3 mb-3 shadow-sm">
                    <i class="fa-solid fa-print me-2"></i> QR 코드 인쇄하기
                </button>
                <p class="text-muted" style="font-size: 12px;">
                    <i class="fa-solid fa-circle-info me-1"></i> 인쇄 시 배경 이미지가 포함되도록 설정해 주세요.
                </p>
            </div>
        <% } %>
    </div>
</div>

<script type="text/javascript">
    var storeId = "<%=userStoreId != null ? userStoreId : ""%>";

    if(storeId) {
        new QRCode(document.getElementById("qrcode"), {
            text: storeId, // QR에 담길 텍스트(매장ID)
            width: 280,
            height: 280,
            colorDark : "#000000",
            colorLight : "#ffffff",
            correctLevel : QRCode.CorrectLevel.H
        });
    }
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>